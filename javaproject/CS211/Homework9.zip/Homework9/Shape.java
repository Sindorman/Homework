
public interface Shape {

	public double getArea();
	public double getPerimeter();
	public boolean equals(Shape shape);
}
