
public interface Incrementable {
	
	//public int integer;
	public void increment();
	public int getValue();
}
