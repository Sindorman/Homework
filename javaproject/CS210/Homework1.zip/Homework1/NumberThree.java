public class NumberThree
{
	public static void main(String[] args)
	{
	Upart();
	Downpart();
	Between();
	Upart();
	Downpart();
	Between();
	Downpart();
	Upart();
	Between();
	Downpart();
	}	
	
	public static void Upart()
	{
	System.out.println("  -------");
	System.out.println(" /       \\");
	System.out.println("/         \\");
	}
	public static void Downpart()
	{
	System.out.println("\\         /");
    System.out.println(" \\       /");
	System.out.println("  -------");
	}
	public static void Between()
	{
	System.out.println("-\"-'-\"-'-\"-");
	}
}