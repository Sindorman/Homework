  public class NumberTwo
{
public static void main(String[] args)
	{
System.out.println("A well-formed Java program has \na main method with { and }\nbraces.\n");
System.out.println("A System.out.println statement\nhas ( and ) and usually a\nString that starts and ends");
System.out.println("with a \" character.(But we type \\\" instead!)");
	}	
}